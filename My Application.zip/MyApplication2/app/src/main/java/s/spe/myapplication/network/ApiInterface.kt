package s.spe.myapplication.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query
import s.spe.myapplication.data.model.ResponseData

interface ApiInterface {

    @GET("everything")
    suspend fun getAllNews(
        @Query("q") q: String?,
        @Query("apiKey") apiKey: String?
    ): Response<ResponseData>
}
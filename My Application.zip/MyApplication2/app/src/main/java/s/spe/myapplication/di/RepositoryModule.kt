package s.spe.myapplication.di

import org.koin.dsl.module
import s.spe.myapplication.data.repository.NewsRepository

val repoModule = module {
    single { NewsRepository(get()) }
}
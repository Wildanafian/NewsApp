package s.spe.myapplication

import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import s.spe.myapplication.di.apiModule
import s.spe.myapplication.di.networkModule
import s.spe.myapplication.di.repoModule
import s.spe.myapplication.di.viewModel

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@MainApplication)
            modules(
                apiModule,
                networkModule,
                repoModule,
                viewModel
            )
        }
    }
}
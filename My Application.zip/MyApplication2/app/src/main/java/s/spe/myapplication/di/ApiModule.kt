package s.spe.myapplication.di

import org.koin.dsl.module
import retrofit2.Retrofit
import s.spe.myapplication.network.ApiInterface

val apiModule = module {
    fun provideApi(retrofit: Retrofit): ApiInterface {
        return retrofit.create(ApiInterface::class.java)
    }

    single { provideApi(get()) }
}
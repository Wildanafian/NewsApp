package s.spe.myapplication.di
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import s.spe.myapplication.feature.home.NewsListViewModel


val viewModel = module {
    viewModel { NewsListViewModel(get()) }
}
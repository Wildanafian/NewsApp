package s.spe.myapplication.feature.detail

import android.os.Bundle
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_detail.*
import s.spe.myapplication.R
import s.spe.myapplication.base.BaseActivity
import s.spe.myapplication.data.model.Article

class Detail : BaseActivity(R.layout.activity_detail) {

    lateinit var data: Article

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        intent.getStringExtra("data").let { data = Gson().fromJson(it, Article::class.java) }

        loadImage(imgNews_detail, data.urlToImage)
        tvNews_content.text = data.content
    }

}